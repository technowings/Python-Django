1)in appointment page there are one form, in that form there are two fileds which you need to modified in- Searchable drop down for choice field in django (without install any additional dependency).
that fileds are --> a)Gender b)Appointment Session
HTML eg.--> https://www.w3schools.com/howto/howto_js_filter_dropdown.asp

2)in appointment page there are one form, in that form there are one filed which you need to modified - placeholder in "DD/MM/YYYY" form.
that is--> a)Appointment Date

3)in appointment page there are one datatable,in that datatable you need to show all saved appointment data(arrenge table header as per appointment table data).